<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&display=swap" rel="stylesheet">
<style>
    /* MODAL STYLES */
    :root {
        --c-blue: #30B0FF;
        --c-green: #80C024;
        --c-orange: #FF9200;
        --c-text: #000000;
        --font-main: 'Montserrat', sans-serif;
    }

    .modal-overlay {
        position: fixed; top: 0; left: 0; width: 100%; height: 100%;
        background: rgba(0,0,0,0.7); z-index: 1000;
        display: none; /* Skryto defaultně */
        justify-content: center; align-items: center;
    }

    .modal-window {
        background: #fff; width: 90%; max-width: 1000px;
        max-height: 90vh; overflow-y: auto;
        display: flex; flex-direction: row;
        border-radius: 8px; box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        font-family: var(--font-main); color: var(--c-text);
        position: relative;
    }

    /* Levá část - Foto */
    .modal-left {
        flex: 1;
        background-size: cover; background-position: center;
        min-height: 300px; position: relative;
    }
    
    .modal-left::after {
        content: ''; position: absolute; top:0; left:0; right:0; bottom:0;
        background: linear-gradient(to bottom, transparent 70%, rgba(0,0,0,0.6));
    }

    /* Pravá část - Formulář */
    .modal-right {
        flex: 1; padding: 40px; display: flex; flex-direction: column;
    }

    .close-modal {
        position: absolute; right: 20px; top: 15px; font-size: 24px; cursor: pointer; color: #333; z-index: 10;
    }

    h2 { font-weight: 600; margin-bottom: 20px; color: var(--c-blue); }
    h3 { font-size: 1.1em; margin-top: 20px; color: var(--c-green); }

    /* Přepínač procházek */
    .walk-selector {
        display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 20px;
    }
    
    .walk-btn {
        padding: 8px 15px; border: 2px solid #ddd; border-radius: 20px;
        cursor: pointer; font-size: 0.9em; transition: 0.3s; background: #fff;
    }

    .walk-btn.active {
        border-color: var(--c-orange); background: var(--c-orange); color: #fff; font-weight: 600;
    }

    /* Anotace */
    .annotation-box ul { padding-left: 20px; margin-bottom: 20px; }
    .annotation-box li { margin-bottom: 5px; font-size: 0.95em; line-height: 1.4; }

    /* Info řádek */
    .info-row {
        background: #f4f4f4; padding: 15px; border-radius: 5px; margin-bottom: 20px;
        border-left: 4px solid var(--c-blue);
    }
    .info-row p { margin: 5px 0; font-weight: 600; }
    .info-label { font-weight: 400; font-size: 0.9em; color: #666; }

    /* Formulářové prvky */
    .form-group { margin-bottom: 15px; }
    label { display: block; margin-bottom: 5px; font-weight: 600; font-size: 0.9em; }
    input, select {
        width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px;
        font-family: var(--font-main); font-size: 1em;
    }

    .price-display {
        font-size: 1.5em; font-weight: 600; color: var(--c-green); text-align: right; margin: 20px 0;
    }

    .btn-submit {
        background: var(--c-blue); color: white; border: none; padding: 15px;
        width: 100%; font-size: 1.1em; font-weight: 600; border-radius: 4px; cursor: pointer;
        transition: background 0.2s;
    }
    .btn-submit:hover { background: #2090dd; }

    /* Responzivita pro mobil */
    @media (max-width: 768px) {
        .modal-window { flex-direction: column; width: 95%; max-height: 95vh; }
        .modal-left { height: 200px; flex: none; }
        .modal-right { padding: 20px; }
    }

</style>

<button onclick="document.getElementById('bookingModal').style.display='flex'">Rezervovat vycházku</button>

<div id="bookingModal" class="modal-overlay">
    <div class="modal-window">
        <span class="close-modal" onclick="document.getElementById('bookingModal').style.display='none'">&times;</span>
        
        <div class="modal-left" id="modalImage" style="background-image: url('img/cesky-kras.jpg');"></div>

        <div class="modal-right">
            <h2>Komentované vycházky přírodou s průvodcem</h2>

            <label>Vyberte trasu:</label>
            <div class="walk-selector">
                <div class="walk-btn active" data-walk="kras" onclick="changeWalk('kras')">CHKO Český kras</div>
                <div class="walk-btn" data-walk="svatojan" onclick="changeWalk('svatojan')">Svatojanský okruh</div>
                <div class="walk-btn" data-walk="krivoklat" onclick="changeWalk('krivoklat')">CHKO Křivoklátsko</div>
                <div class="walk-btn" data-walk="alkazar" onclick="changeWalk('alkazar')">Alkazar</div>
            </div>

            <div class="annotation-box" id="annotationContent">
                </div>

            <div class="info-row">
                <p><span class="info-label">Průvodce:</span> <span id="guideName">Jan Novák</span></p>
                <p><span class="info-label">Datum:</span> <span id="walkDate">20. 5. 2024</span></p>
            </div>

            <form id="reservationForm" onsubmit="submitForm(event)">
                <input type="hidden" name="walk_id" id="inputWalkId" value="kras">
                <input type="hidden" name="walk_name" id="inputWalkName" value="CHKO Český kras">
                
                <div class="form-group">
                    <label>Váš e-mail</label>
                    <input type="email" name="email" required placeholder="jan.novak@email.cz">
                </div>

                <div class="form-group">
                    <label>Počet účastníků</label>
                    <select name="count" id="participantCount" onchange="calculatePrice()">
                        </select>
                </div>

                <div class="price-display" id="finalPrice">Zdarma</div>

                <button type="submit" class="btn-submit" id="submitBtn">Zaplatit a rezervovat místo</button>
            </form>
        </div>
    </div>
</div>
<script>
// DATA PROCHÁZEK
const walks = {
    'kras': {
        title: 'CHKO Český kras',
        // Placeholder: Krajina krasu
        img: 'https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=800&q=80', 
        guide: 'RNDr. Petr Skála',
        date: '15. 4. 2024',
        pricePerPerson: 0,
        desc: [
            'Unikátní vápencová krajina a krasové jevy.',
            'Návštěva národní přírodní rezervace Karlštejn.',
            'Vyhlídky do hlubokých kaňonů.',
            'Historie těžby vápence v lomech Amerika.',
            'Délka trasy cca 8 km, střední náročnost.'
        ]
    },
    'svatojan': {
        title: 'Svatojanský okruh',
        // Placeholder: Skála a výhled
        img: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=800&q=80', 
        guide: 'Mgr. Jana Veselá',
        date: '22. 4. 2024',
        pricePerPerson: 100,
        desc: [
            'Poutní místo Svatý Jan pod Skálou.',
            'Výstup na vyhlídku u kříže.',
            'Prohlídka benediktinského kláštera.',
            'Návštěva jeskyně sv. Ivana.',
            'Skanzen Solvayovy lomy.'
        ]
    },
    'krivoklat': {
        title: 'CHKO Křivoklátsko',
        // Placeholder: Hluboký les
        img: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=800&q=80', 
        guide: 'Ing. Karel Les',
        date: '12. 5. 2024',
        pricePerPerson: 100,
        desc: [
            'Hluboké lesy a biosférická rezervace.',
            'Vyhlídky na řeku Berounku.',
            'Pozorování lesní zvěře v oboře.',
            'Historie hradu Křivoklát a okolí.',
            'Vodní nádrž Klíčava.'
        ]
    },
    'alkazar': {
        title: 'Alkazar',
        // Placeholder: Skalní stěna / lom
        img: 'https://images.unsplash.com/photo-1559223607-a43c990c692c?w=800&q=80', 
        guide: 'Tomáš Průvodce',
        date: '19. 5. 2024',
        pricePerPerson: 100,
        desc: [
            'Bývalý lom Alkazar a jeho historie.',
            'Horolezecká stěna a podzemní štoly.',
            'Údolí řeky Berounky.',
            'Vlaková trať a technické památky.',
            'Nenáročná trasa vhodná i pro rodiny.'
        ]
    }
};

// Inicializace dropdownu 1-20
const select = document.getElementById('participantCount');
for (let i = 1; i <= 20; i++) {
    let opt = document.createElement('option');
    opt.value = i;
    opt.innerHTML = i;
    select.appendChild(opt);
}

// Funkce pro změnu procházky
function changeWalk(id) {
    const data = walks[id];
    
    // UI Update
    document.querySelectorAll('.walk-btn').forEach(b => b.classList.remove('active'));
    document.querySelector(`.walk-btn[data-walk="${id}"]`).classList.add('active');
    
    // Image placeholder
    document.getElementById('modalImage').style.backgroundImage = `url('${data.img}')`;
    
    // Texty
    document.getElementById('guideName').innerText = data.guide;
    document.getElementById('walkDate').innerText = data.date;
    document.getElementById('inputWalkId').value = id;
    document.getElementById('inputWalkName').value = data.title;
    
    // Anotace (seznam)
    let ul = '<ul>';
    data.desc.forEach(point => {
        ul += `<li>${point}</li>`;
    });
    ul += '</ul>';
    document.getElementById('annotationContent').innerHTML = ul;

    calculatePrice();
}

// Výpočet ceny
function calculatePrice() {
    const id = document.getElementById('inputWalkId').value;
    const count = parseInt(document.getElementById('participantCount').value);
    const pricePerPerson = walks[id].pricePerPerson;
    
    let total = count * pricePerPerson;
    
    if (total === 0) {
        document.getElementById('finalPrice').innerText = "Zdarma";
        document.getElementById('submitBtn').innerText = "Rezervovat zdarma";
    } else {
        document.getElementById('finalPrice').innerText = total + " Kč";
        document.getElementById('submitBtn').innerText = "Zaplatit a rezervovat (" + total + " Kč)";
    }
}

// Odeslání formuláře (AJAX)
function submitForm(e) {
    e.preventDefault();
    const btn = document.getElementById('submitBtn');
    const originalText = btn.innerText;
    btn.disabled = true;
    btn.innerText = "Zpracovávám...";

    const formData = new FormData(document.getElementById('reservationForm'));

    fetch('rezervace.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if(data.success) {
            alert("Rezervace byla úspěšná! Potvrzení dorazí na váš e-mail.");
            document.getElementById('bookingModal').style.display = 'none';
        } else {
            alert("Chyba: " + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert("Došlo k chybě při komunikaci se serverem.");
    })
    .finally(() => {
        btn.disabled = false;
        btn.innerText = originalText;
    });
}

// Spustit výchozí
changeWalk('kras');
</script>